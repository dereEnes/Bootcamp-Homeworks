﻿namespace First.App.Models
{
    public class SuccessViewModel
    {
        public int StatusCode { get; set; }
        public string Message { get; set; }
    }
}
