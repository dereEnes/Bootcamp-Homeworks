﻿namespace First.App.Core.Abrastract
{
    public interface IEmail
    {
        void Send();
    }
}
