﻿namespace First.App.Core.Extensions
{
    public static class IntegerExtensions
    {
        public static bool IsGreaterThan(this int number)
        {
            return number > 0;
        }
    }
}
