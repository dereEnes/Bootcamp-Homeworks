﻿namespace First.App.Business.DTOs
{
    public class Product
    {
    }
}