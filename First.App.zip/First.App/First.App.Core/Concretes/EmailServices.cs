﻿using First.App.Core.Abrastract;
using System;

namespace First.App.Core.Concretes
{
    public class EmailServices : IEmail
    {
        public void Send()
        {
            throw new NotImplementedException();
        }
    }
}
