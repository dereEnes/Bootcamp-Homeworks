﻿namespace First.API.Models
{
    public class CompanyResponse
    {
        public object Data { get; set; }
        public bool Success { get; set; }
        public string Error { get; set; }
    }
}
