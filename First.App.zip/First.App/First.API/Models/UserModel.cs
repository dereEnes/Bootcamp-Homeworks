﻿namespace First.API.Models
{
    public class UserModel
    {
        public string Name { get; set; }
        public string Password { get; set; }
    }
}
